#!/bin/bash
#SBATCH -A kurs00051
#SBATCH -p kurs00051
#SBATCH --reservation=kurs00051
#SBATCH -J daxpy
#SBATCH --mail-type=ALL
#SBATCH -e "/home/kurse/kurs00051/oo73xige/Practical01/Task1/test1.err.%j"
#SBATCH -o "/home/kurse/kurs00051/oo73xige/Practical01/Task1/test1.out.%j"
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --mem-per-cpu=3800
#SBATCH -t 00:10:00

module purge
module load gcc
module load openmpi

cd /home/kurse/kurs00051/oo73xige/Practical01/Task1
make
./daxpy 1
./daxpy 2
./daxpy 4
./daxpy 8
./daxpy 16