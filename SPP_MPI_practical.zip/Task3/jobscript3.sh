#!/bin/bash
#SBATCH -A kurs00051
#SBATCH -p kurs00051
#SBATCH --reservation=kurs00051
#SBATCH -J heated-plate
#SBATCH --mail-type=ALL
#SBATCH -e "/home/kurse/kurs00051/oo73xige/Practical02/Task3/test1.err.%j"
#SBATCH -o "/home/kurse/kurs00051/oo73xige/Practical02/Task3/test1.out.%j"
#SBATCH -N 1
#SBATCH -n 8
#SBATCH --mem-per-cpu=3800
#SBATCH -t 00:10:00

module purge
module load gcc
module load openmpi

cd /home/kurse/kurs00051/oo73xige/Practical02/Task3
make
mpiexec -n 8 ./heated-plate
