//  Author:
//
//    Yannic Fischler
//    Modfied for WS21 by Sebastian Kreutzer

#include <stdlib.h>
#include <stdio.h>

#include <mpi.h>


int world_size;
int world_rank;


int main(int argc, char** argv) {
  MPI_Init(&argc, &argv);

  // TODO: Store number of processes in world_size
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);
  // TODO: Store current rank in world_rank
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

  if (argc != 2) {
    printf("Add number of sampling points as parameter\n");
    return 1;
  }

  int numberOfPoints = atoi(argv[1]);

  // TODO: Make sure that numberOfPoints is valid
  if (world_size >= numberOfPoints) {
    numberOfPoints += world_size - numberOfPoints;
  }

  if (world_rank == 0) {
    printf("Running with %d processes\n", world_size);
  }

  double result = 0;

  // TODO: Implement the Monte-Carlo simulation as described in the task.
  //       Store the solution in "result".
  int i, numsent, sender, done;
  MPI_Status status;
  int a = -1;
  int b = 1;
  unsigned int seed;
  double randnum;
  double* partialSums = (double*)malloc(numberOfPoints*sizeof(double));
  if(world_rank == 0) {
    numsent = 0;
    seed = (unsigned int)(time(NULL));
    srand(seed);
    for(int i = 0; i < world_size - 1; i++) {
      randnum = (double)rand() / (double)(RAND_MAX/2.0) - 1;
      MPI_Send(&randnum, 1, MPI_DOUBLE, i+1, i, MPI_COMM_WORLD);
      numsent++;
    }
    for(int i = 0; i < numberOfPoints; i++) {
      MPI_Recv(&partialSums[i], 1, MPI_DOUBLE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
      sender = status.MPI_SOURCE;

      if(numsent < numberOfPoints) {
        randnum = (double)rand() / (double)(RAND_MAX/2.0) - 1;
        MPI_Send(&randnum, 1, MPI_DOUBLE, sender, numsent, MPI_COMM_WORLD);
        numsent++;
      }
      else {
        MPI_Send(MPI_BOTTOM, 0, MPI_DOUBLE, sender, numberOfPoints + 1, MPI_COMM_WORLD);
      }
    }
  }
  else {
    done = 0;
    while(!done) {
      MPI_Recv(&randnum, 1, MPI_DOUBLE, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
      done = status.MPI_TAG == numberOfPoints + 1;
      if(!done) {
        partialSums[status.MPI_TAG] = 2.0/(1.0+(randnum)*(randnum));
        MPI_Send(&partialSums[status.MPI_TAG], 1, MPI_DOUBLE, 0, status.MPI_TAG, MPI_COMM_WORLD);
      }
    }
  }

  if (world_rank == 0) {
    for(int i = 0; i < numberOfPoints; i++) {
      result += partialSums[i];
    }
    result = ((double)(b-a)/(double)numberOfPoints) * result;
    printf("%f\n", result);
  }

  free(partialSums);

  MPI_Finalize();

  return 0;

}