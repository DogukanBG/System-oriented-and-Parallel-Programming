#!/bin/bash
#SBATCH -A kurs00051
#SBATCH -p kurs00051
#SBATCH --reservation=kurs00051
#SBATCH -J integral
#SBATCH --mail-type=ALL
#SBATCH -e "/home/kurse/kurs00051/oo73xige/Practical02/Task2/test1.err.%j"
#SBATCH -o "/home/kurse/kurs00051/oo73xige/Practical02/Task2/test1.out.%j"
#SBATCH -N 1
#SBATCH -n 8
#SBATCH --mem-per-cpu=3800
#SBATCH -t 00:10:00

module purge
module load gcc
module load openmpi
module load scorep

cd /home/kurse/kurs00051/oo73xige/Practical02/Task2
make
export SCOREP_ENABLE_TRACING=true
export SCOREP_EXPERIMENT_DIRECTORY=/work/scratch/kurse/kurs00051/oo73xige/Experiment1
mpirun -n 8 ./integral 100000
