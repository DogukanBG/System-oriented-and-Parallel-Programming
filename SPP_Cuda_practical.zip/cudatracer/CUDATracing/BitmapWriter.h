#ifndef BITMAPWRITER_H
#define BITMAPWRITER_H
int writeBMPToFile(float* data, const int w, const int h);
#endif