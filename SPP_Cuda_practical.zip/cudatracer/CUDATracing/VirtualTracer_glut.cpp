#include "virtualTracer_glut.h"

virtualTracer::virtualTracer(int width, int height)
{
		height = height;
		width = width;
		rendered = false;
}

virtualTracer::~virtualTracer()
{
}
