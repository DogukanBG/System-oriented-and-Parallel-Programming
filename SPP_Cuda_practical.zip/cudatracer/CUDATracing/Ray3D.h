#ifndef RAY3D_H
#define RAY3D_H

#include "DirectionPoint.h"

class Point;
class Direction;

/*class Ray3D
{
public:
	Point ori;
	Direction dir;

	Ray3D();
	Ray3D(Point ori, Direction dir);
	Ray3D(Point p0, Point p1);
};*/

#endif